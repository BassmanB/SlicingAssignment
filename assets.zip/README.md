#FlwrSpot Slicing Assignment

Implementation of flower details, flower-details(mobile) and Profile pages.
Mobile version is displaying when width dimension is smaller than 1230px. Profie page is visible after clicking on picture in right top corner.

##Requirements

There are no reqirements to run FlowrSpot Assignment project

##Install

To run FlwrSpot project is enought to move index.html file and assets and dist folders on server. 

##Languages & tools

Without any frameworks and libraries.

####Html
####JavaScript
####CSS 



